# -*- coding: utf-8 -*-
"""
Created on Tue May  7 23:12:07 2024

@author: smqh1
"""

import selenium
from selenium import webdriver
from selenium.webdriver.firefox.firefox_binary import FirefoxBinary
from selenium.webdriver.edge.service import Service
from selenium.webdriver.firefox.options import Options
import time
from bs4 import BeautifulSoup
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import NoSuchElementException
import csv

options = Options()
options.binary_location = "C:\\Program Files\\Mozilla Firefox\\firefox.exe"

options = webdriver.EdgeOptions()
# options.use_chromium = True

# 隐藏浏览器
# options.add_argument('--headless')
#options.add_argument('-enable-webgl --no-sandbox --disable-dev-shm-usage')
#options.add_experimental_option('excludeSwitches', ['enable-automation'])
#user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36 Edg/101.0.1210.53'
#options.add_argument(f'user-agent={user_agent}')

# 取消浏览器被自动控制字样
#options.add_argument('--disable-blink-features=AutomationControlled')
#ptions.add_experimental_option("excludeSwitches", ["enable-automation"])
#options.add_experimental_option('useAutomationExtension', False)

#driver = webdriver.Firefox(executable_path="C:\\crawling_back\\edgedriver_win64\\geckodriver.exe",options=options)
driver_path = 'C:\crawling_back\edgedriver_win64\msedgedriver.exe'
driver = webdriver.Edge(service=Service(driver_path), options = options)

url_list = []

start_url = 'https://www.nmpa.gov.cn/datasearch/home-index.html#category=yp'

driver.get(start_url)
time.sleep(8)

action = ActionChains(driver)
action.move_by_offset(100, 100).click().perform()

time.sleep(5)

first_click = driver.find_element_by_xpath('//*[@id="home"]/main/div[2]/div[2]/div[1]/div[1]/div[5]/a/span')
"""//*[@id="home"]/main/div[2]/div[2]/div[1]/div[1]/div[4]/a/span"""

first_click.click()

search_box = driver.find_element_by_xpath('//*[@id="home"]/main/div[1]/div[7]/div/div[2]/input')
search_box.send_keys("国备2024")
search_box.send_keys(Keys.RETURN)


time.sleep(5)

driver.switch_to.window(driver.window_handles[0])

action = ActionChains(driver)
action.move_by_offset(100, 100).click().perform()

time.sleep(5)

driver.close()

driver.switch_to.window(driver.window_handles[0])
action = ActionChains(driver)
action.move_by_offset(100, 100).click().perform()
j=1


dpaths = ['//*[@id="dataTable"]/div[2]/table/tbody/tr[' + str(i) + ']/td[2]/div/div/div' for i in range(1,15)]

column_names = ["备案号",
                "药品通用名称",
                "药品批准文号/注册证号/原料药登记号",
                "上市许可持有人/原料药申请人",
                "上市许可持有人地址",
                "生产企业名称",
                "生产企业地址",
                "境外生产药品注册代理机构",
                "境外生产药品注册代理机构地址",
                "备案内容","备案日期",
                "备案机关","备注","注"]



table_data = []
while j<=97:
    time.sleep(5)
    i = 1
    
    
    while i <= 10:
        page_data = []
        driver.switch_to.window(driver.window_handles[0])
        path = '//*[@id="home"]/div[3]/div[2]/div/div/div[3]/table/tbody/tr['+str(i)+']/td[5]/div/button'
        print(path)
        try:
            button = driver.find_element_by_xpath(path)
            button.click()
        except:
            i = 11
            continue
        time.sleep(10)
        driver.switch_to.window(driver.window_handles[1])

        for dpath in dpaths:
            elements = driver.find_element_by_xpath(dpath)
            data = [elements.text]
            page_data.append(data)
        
        table_data.extend(list(zip(*page_data)))
        
        time.sleep(5)
        driver.close()
        time.sleep(2)
        driver.switch_to.window(driver.window_handles[0])
        print(i)
        i = i+1
    next_page = driver.find_element_by_xpath('//*[@id="home"]/div[3]/div[3]/div/div/button[2]')
    try:
        """next_page = driver.find_element_by_xpath('//*[@id="home"]/div[3]/div[3]/div/div/button[2]')"""
        next_page = driver.find_element_by_class_name("btn-next")
        if "disable" in next_page.get_attribute("class"):
            j = 10000
            continue        
        else:
            next_page.click()
            j=j+1
            time.sleep(5)
    except NoSuchElementException:
        break
    
    

    """table_data.extend(list(zip(*page_data)))"""
    
driver.quit()


table_data.insert(0, column_names)

file_path = "D:\\scraper\\Hackthon.csv"
with open(file_path, 'w', newline='', encoding='utf-8-sig') as file:
    writer = csv.writer(file)
    writer.writerows(table_data)
    
"""while True:
    time.sleep(5)
    links = driver.find_element_by_xpath()"""
